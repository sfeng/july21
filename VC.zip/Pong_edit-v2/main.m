//
//  main.m
//  Pong
//
//  Created by NYU User on 4/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
// -modified by sha sha feng 7/28/11
// added grass background, changed colors/size of shapes,
// counter for # of collisions via NSLog output to Console
// generate sound when collision occurs
// change speed after collision
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"PongAppDelegate");
	[pool release];
	return retVal;
}
