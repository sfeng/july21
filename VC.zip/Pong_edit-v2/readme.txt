Pong
modified by sha sha feng 7/28/11
 added grass background, changed colors/size of shapes,
 counter for # of collisions via NSLog output to Console
 generate sound when collision occurs
 change speed after collision