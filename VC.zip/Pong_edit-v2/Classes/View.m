//
//  View.m
//  Pong
//
//  Created by NYU User on 4/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"
#import <QuartzCore/QuartzCore.h>

@implementation View

- (id) initWithFrame: (CGRect) frame {
    if ((self = [super initWithFrame: frame])) {
		// Initialization code
		//self.backgroundColor = [UIColor greenColor];
		self.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.2 blue: 0.5 alpha: 0.7];
		
		//Create the paddle.
	    //frame = CGRectMake(40, 100, 20, 100);
		frame = CGRectMake(20, 20, 20, 20);
		paddle = [[UIView alloc] initWithFrame: frame];
		paddle.backgroundColor = [UIColor yellowColor];
		[self addSubview: paddle];
		
		//Create the ball in the upper left corner of this View.
		frame = CGRectMake(0, 0, 20, 20);
		ball = [[UIView alloc] initWithFrame: frame];
		ball.backgroundColor = [UIColor whiteColor];
		[self addSubview: ball];
		
		//Ball initially moves to lower right.
		dx = 2;
		dy = 2;
		points=0;
    }
	
	
	
    return self;
}

//Change the ball's direction of motion,
//if necessary to avoid an impending collision.

- (void) bounce {	
	//Where the ball would be if its horizontal motion were allowed
	//to continue for one more move.
	CGRect horizontal = ball.frame;
	horizontal.origin.x += dx;

	//Where the ball would be if its vertical motion were allowed
	//to continue for one more move.
	CGRect vertical = ball.frame;
	vertical.origin.y += dy;

	
	//Ball must remain inside self.bounds.
	if (!CGRectEqualToRect(horizontal, CGRectIntersection(horizontal, self.bounds))) {
		//Ball will bounce off left or right edge of View.
		dx = -dx-points;
		
	}
		
	if (!CGRectEqualToRect(vertical, CGRectIntersection(vertical, self.bounds))) {
		//Ball will bounce off top or bottom edge of View.
		dy = -dy;
		
		
	}
	
	//If the ball is not currently intersecting the paddle,
	if (!CGRectIntersectsRect(ball.frame, paddle.frame)) {
		
		//but if the ball will intersect the paddle on the next move,
		if ((CGRectIntersectsRect(horizontal, paddle.frame)) || (CGRectIntersectsRect(vertical, paddle.frame))) {
			dx = -dx;
			dy = -dy;
			points++;
			
			/**sound***/
			NSBundle *bundle = [NSBundle mainBundle];
			if (bundle == nil) {
				NSLog(@"could not get the main bundle");
				//return YES;
			}
			
			//The path is the filename.
			NSString *path =
			[bundle pathForResource: @"sound" ofType: @"mp3"];
			if (path == nil) {
				NSLog(@"could not get the path");
			//	return YES;
			}
			NSLog(@"path == \"%@\"", path);
			
			NSURL *url = [NSURL fileURLWithPath: path isDirectory: NO];
			NSLog(@"url == \"%@\"", url);
			
			NSError *error = nil;
			player = [[AVAudioPlayer alloc]
					  initWithContentsOfURL: url error: &error];
			if (player == nil) {
				NSLog(@"error == %@", error);
				[error release];
				[self release];
			//	return YES;
			}
			
			player.volume = 1.0;		//the default
			player.numberOfLoops = 0;	//negative number for infinite loop
			/*
			 NSLog(@"player.numberOfChannels == %u",
			 player.numberOfChannels); //mono or stereo
			 */
			
			if (![player prepareToPlay]) {
				NSLog(@"could not prepare to play");
			//	return YES;
			}
			
			if (![player play]) {
				NSLog(@"could not play");
			}	
			
			
			
			/***/
			
			
		}
		
		/*if (CGRectIntersectsRect(vertical, paddle.frame)) {
			dy = -dy;
			points++;
		
		}*/
	}
	
	NSLog(@"\nTotal Points: %d", points);
	
		
}

- (void) touchesMoved: (NSSet *) touches withEvent: (UIEvent *) event {
	UITouch *t = [touches anyObject];
	CGPoint p = [t locationInView: self];
	CGFloat y = p.y;
	
	//Don't let the paddle move off the bottom or top of the View.
	CGFloat half = paddle.bounds.size.height / 2;
	y = MIN(y, self.bounds.size.height - half); //don't let y get too big
	y = MAX(y, half);                         //don't let y get too small
	
	paddle.center = CGPointMake(paddle.center.x, y);
	[self bounce];
}

- (void) move: (CADisplayLink *) displayLink {
	//NSLog(@"%.15g", displayLink.timestamp);	//15 significant digits

	ball.center = CGPointMake(ball.center.x + dx, ball.center.y + dy);
	[self bounce];
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void) drawRect: (CGRect) rect {
	
	// Drawing code
	/*source:iphonedevelopertips.com/graphics/creating-background-patterns.html
	 */
	UIImage* backgroundPatternImage = [UIImage imageNamed:@"grass.jpg"];
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGRect tiledRect;
	tiledRect.origin = CGPointZero;
	tiledRect.size = backgroundPatternImage.size;
	CGContextDrawTiledImage(context,tiledRect,backgroundPatternImage.CGImage);
	
/*	
	
	NSString *s = [NSString stringWithFormat: @"%d", points];
	UIFont *f = [UIFont systemFontOfSize: 6 * 10];
	CGSize size = [s sizeWithFont: f];
	
	CGRect b = self.bounds;
	CGFloat x = b.origin.x + (b.size.width - size.width) / 2;
	CGFloat y = b.origin.y + (b.size.height - size.height) / 2;
	[s drawAtPoint: CGPointMake(x, y) withFont: f];
	NSLog(@"\n**Total Points: %d", points);
*/	
}


- (void) dealloc {
	[super dealloc];
}


@end
