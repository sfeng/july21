//
//  View.h
//  Pong
//
//  Created by NYU User on 4/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVAudioPlayer.h>

@interface View: UIView {

	UIView *paddle;
	UIView *ball;
	CGFloat dx, dy;	//direction and speed of ball's motion
    int points; //counts # of collisions - see Console
	AVAudioPlayer *player;
}

- (void) move: (CADisplayLink *) displayLink;
@end
